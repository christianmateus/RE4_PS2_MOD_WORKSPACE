namespace RE4_PS2_MOD_WORKSPACE
{
    partial class Form1
    {
        private System.ComponentModel.IContainer? components = null;
        private Panel pnlSidebar = null!, pnlTop = null!, pnlContent = null!, pnlDashboard = null!, pnlWorkspace = null!, pnlTools = null!, pnlBuild = null!;
        private Label lblLogo = null!, lblLogoSub = null!, lblVersion = null!, lblTopTitle = null!;
        private Button btnNavDashboard = null!, btnNavWorkspace = null!, btnNavTools = null!, btnNavBuild = null!, btnTopBuild = null!;
        private Label lblCardWorkspaceValue = null!, lblCardIsoValue = null!, lblCardDatValue = null!, lblCardStatusValue = null!, lblWorkspaceCurrent = null!;
        private TextBox txtWorkspacePath = null!, txtIsoPath = null!, txtDatPath = null!, txtIsoAfs = null!, txtDatTool = null!, txtTplManager = null!, txtPcsx2 = null!;
        private Button btnBrowseWorkspace = null!, btnCreateWorkspace = null!, btnOpenWorkspace = null!, btnBrowseIso = null!, btnBrowseDat = null!;
        private Button btnBrowseIsoAfs = null!, btnBrowseDatTool = null!, btnBrowseTpl = null!, btnBrowsePcsx2 = null!;
        private Button btnOpenIsoAfs = null!, btnOpenDatTool = null!, btnOpenTpl = null!, btnOpenPcsx2 = null!;
        private Button btnBuildOpenDat = null!, btnBuildOpenIsoAfs = null!, btnBuildOpenPcsx2 = null!, btnBuildFolder = null!, btnDashboardWorkspace = null!;
        private RichTextBox rtbBuildLog = null!;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            pnlSidebar = new Panel(); lblVersion = new Label(); btnNavBuild = new Button(); btnNavTools = new Button(); btnNavWorkspace = new Button(); btnNavDashboard = new Button(); lblLogoSub = new Label(); lblLogo = new Label();
            pnlTop = new Panel(); btnTopBuild = new Button(); lblTopTitle = new Label(); pnlContent = new Panel();
            pnlDashboard = new Panel(); pnlWorkspace = new Panel(); pnlTools = new Panel(); pnlBuild = new Panel();
            SuspendLayout();

            // Form
            AutoScaleMode = AutoScaleMode.Dpi; BackColor = Color.FromArgb(14, 15, 18); ClientSize = new Size(1280, 760); ForeColor = Color.FromArgb(239, 241, 245); Font = new Font("Segoe UI", 9.5F); MinimumSize = new Size(1050, 650); StartPosition = FormStartPosition.CenterScreen; Text = "RE4 PS2 Mod Workspace";

            // Sidebar
            pnlSidebar.BackColor = Color.FromArgb(20, 22, 27); pnlSidebar.Dock = DockStyle.Left; pnlSidebar.Padding = new Padding(16, 20, 16, 16); pnlSidebar.Width = 230;
            lblLogo.Text = "RE4  PS2"; lblLogo.Dock = DockStyle.Top; lblLogo.Height = 36; lblLogo.Font = new Font("Segoe UI Semibold", 19F); lblLogo.ForeColor = Color.FromArgb(239, 241, 245);
            lblLogoSub.Text = "MOD WORKSPACE"; lblLogoSub.Dock = DockStyle.Top; lblLogoSub.Height = 45; lblLogoSub.Font = new Font("Segoe UI Semibold", 9F); lblLogoSub.ForeColor = Color.FromArgb(196, 56, 56);
            SetupNav(btnNavDashboard, "  Dashboard", btnNavDashboard_Click); SetupNav(btnNavWorkspace, "  Workspace", btnNavWorkspace_Click); SetupNav(btnNavTools, "  Tools", btnNavTools_Click); SetupNav(btnNavBuild, "  Build", btnNavBuild_Click);
            lblVersion.Text = "v0.1.0"; lblVersion.Dock = DockStyle.Bottom; lblVersion.Height = 30; lblVersion.ForeColor = Color.FromArgb(145, 151, 163); lblVersion.TextAlign = ContentAlignment.MiddleLeft;
            pnlSidebar.Controls.Add(btnNavBuild); pnlSidebar.Controls.Add(btnNavTools); pnlSidebar.Controls.Add(btnNavWorkspace); pnlSidebar.Controls.Add(btnNavDashboard); pnlSidebar.Controls.Add(lblLogoSub); pnlSidebar.Controls.Add(lblLogo); pnlSidebar.Controls.Add(lblVersion);

            // Top
            pnlTop.BackColor = Color.FromArgb(14, 15, 18); pnlTop.Dock = DockStyle.Top; pnlTop.Height = 72; pnlTop.Padding = new Padding(30, 17, 30, 10);
            lblTopTitle.Text = "RE4 PS2 Mod Workspace"; lblTopTitle.Dock = DockStyle.Left; lblTopTitle.Width = 390; lblTopTitle.Font = new Font("Segoe UI Semibold", 15F); lblTopTitle.TextAlign = ContentAlignment.MiddleLeft;
            SetupButton(btnTopBuild, "BUILD", Color.FromArgb(196, 56, 56), 110); btnTopBuild.Dock = DockStyle.Right; btnTopBuild.Click += btnTopBuild_Click;
            pnlTop.Controls.Add(btnTopBuild); pnlTop.Controls.Add(lblTopTitle);

            // Content
            pnlContent.BackColor = Color.FromArgb(14, 15, 18); pnlContent.Dock = DockStyle.Fill; pnlContent.Padding = new Padding(30, 10, 30, 24); pnlContent.AutoScroll = true;
            SetupPage(pnlDashboard); SetupPage(pnlWorkspace); SetupPage(pnlTools); SetupPage(pnlBuild);
            BuildDashboardDesigner(); BuildWorkspaceDesigner(); BuildToolsDesigner(); BuildBuildDesigner();
            pnlContent.Controls.Add(pnlBuild); pnlContent.Controls.Add(pnlTools); pnlContent.Controls.Add(pnlWorkspace); pnlContent.Controls.Add(pnlDashboard);

            Controls.Add(pnlContent); Controls.Add(pnlTop); Controls.Add(pnlSidebar);
            ResumeLayout(false);
        }

        private void SetupPage(Panel panel) { panel.BackColor = Color.FromArgb(14, 15, 18); panel.Dock = DockStyle.Fill; panel.AutoScroll = true; }
        private void SetupNav(Button b, string text, EventHandler handler) { b.Text = text; b.Dock = DockStyle.Top; b.Height = 48; b.FlatStyle = FlatStyle.Flat; b.FlatAppearance.BorderSize = 0; b.FlatAppearance.MouseOverBackColor = Color.FromArgb(27, 30, 36); b.BackColor = Color.FromArgb(20, 22, 27); b.ForeColor = Color.FromArgb(145, 151, 163); b.TextAlign = ContentAlignment.MiddleLeft; b.Cursor = Cursors.Hand; b.Click += handler; }
        private void SetupButton(Button b, string text, Color color, int width) { b.Text = text; b.Width = width; b.Height = 38; b.BackColor = color; b.ForeColor = Color.FromArgb(239, 241, 245); b.FlatStyle = FlatStyle.Flat; b.FlatAppearance.BorderSize = 0; b.Cursor = Cursors.Hand; b.Font = new Font("Segoe UI Semibold", 9F); }
        private Label AddHeader(Panel parent, string title, string subtitle) { var h = new Label { Text = title, Left = 0, Top = 5, Width = 760, Height = 34, Font = new Font("Segoe UI Semibold", 21F), ForeColor = Color.FromArgb(239, 241, 245) }; var d = new Label { Text = subtitle, Left = 2, Top = 42, Width = 880, Height = 28, ForeColor = Color.FromArgb(145, 151, 163) }; parent.Controls.Add(h); parent.Controls.Add(d); return h; }
        private Panel AddCard(Panel parent, string caption, int x, out Label value) { var p = new Panel { Left = x, Top = 90, Width = 215, Height = 105, BackColor = Color.FromArgb(27, 30, 36), Padding = new Padding(16) }; var c = new Label { Text = caption, Dock = DockStyle.Top, Height = 24, ForeColor = Color.FromArgb(145, 151, 163), Font = new Font("Segoe UI Semibold", 8.5F) }; value = new Label { Dock = DockStyle.Fill, ForeColor = Color.FromArgb(239, 241, 245), Font = new Font("Segoe UI Semibold", 11F), TextAlign = ContentAlignment.MiddleLeft, AutoEllipsis = true }; p.Controls.Add(value); p.Controls.Add(c); parent.Controls.Add(p); return p; }
        private TextBox AddPathField(Panel parent, string label, int top, out Button browse) { parent.Controls.Add(new Label { Text = label, Left = 0, Top = top, Width = 300, Height = 22, ForeColor = Color.FromArgb(239, 241, 245), Font = new Font("Segoe UI Semibold", 10F) }); var t = new TextBox { Left = 0, Top = top + 27, Width = 690, Height = 36, BackColor = Color.FromArgb(27, 30, 36), ForeColor = Color.FromArgb(239, 241, 245), BorderStyle = BorderStyle.FixedSingle, Font = new Font("Segoe UI", 10F) }; browse = new Button { Left = 705, Top = top + 26 }; SetupButton(browse, "PROCURAR", Color.FromArgb(34, 37, 44), 120); parent.Controls.Add(t); parent.Controls.Add(browse); return t; }
        private TextBox AddToolField(Panel parent, string label, int top, out Button browse, out Button open) { parent.Controls.Add(new Label { Text = label, Left = 0, Top = top, Width = 220, Height = 22, ForeColor = Color.FromArgb(239, 241, 245), Font = new Font("Segoe UI Semibold", 10F) }); var t = new TextBox { Left = 0, Top = top + 27, Width = 620, Height = 36, BackColor = Color.FromArgb(27, 30, 36), ForeColor = Color.FromArgb(239, 241, 245), BorderStyle = BorderStyle.FixedSingle, Font = new Font("Segoe UI", 10F) }; browse = new Button { Left = 635, Top = top + 26 }; SetupButton(browse, "...", Color.FromArgb(34, 37, 44), 45); open = new Button { Left = 695, Top = top + 26 }; SetupButton(open, "ABRIR", Color.FromArgb(196, 56, 56), 100); parent.Controls.Add(t); parent.Controls.Add(browse); parent.Controls.Add(open); return t; }

        private void BuildDashboardDesigner()
        {
            AddHeader(pnlDashboard, "Dashboard", "Seu ponto central para editar, reconstruir e testar Resident Evil 4 no PS2.");
            AddCard(pnlDashboard, "WORKSPACE", 0, out lblCardWorkspaceValue); AddCard(pnlDashboard, "ISO BASE", 229, out lblCardIsoValue); AddCard(pnlDashboard, "DAT ATIVO", 458, out lblCardDatValue); AddCard(pnlDashboard, "STATUS", 687, out lblCardStatusValue);
            pnlDashboard.Controls.Add(new Label { Text = "Fluxo rápido", Left = 0, Top = 225, Width = 500, Height = 26, Font = new Font("Segoe UI Semibold", 13F) });
            pnlDashboard.Controls.Add(new Label { Text = "Mantenha os originais intactos e trabalhe dentro do workspace.", Left = 0, Top = 253, Width = 850, Height = 25, ForeColor = Color.FromArgb(145, 151, 163) });
            string[] steps = { "1   Abrir / criar workspace", "2   Selecionar ISO base", "3   Selecionar DAT do cenário", "4   Editar com suas ferramentas", "5   Repack + importar na ISO" }; int y = 292;
            foreach (string step in steps) { var p = new Panel { Left = 0, Top = y, Width = 902, Height = 46, BackColor = Color.FromArgb(27, 30, 36) }; p.Controls.Add(new Label { Text = step, Dock = DockStyle.Fill, Padding = new Padding(15, 0, 0, 0), TextAlign = ContentAlignment.MiddleLeft }); pnlDashboard.Controls.Add(p); y += 52; }
            btnDashboardWorkspace = new Button { Left = 0, Top = y + 10 }; SetupButton(btnDashboardWorkspace, "CONFIGURAR WORKSPACE", Color.FromArgb(196, 56, 56), 210); btnDashboardWorkspace.Click += btnDashboardWorkspace_Click; pnlDashboard.Controls.Add(btnDashboardWorkspace);
        }

        private void BuildWorkspaceDesigner()
        {
            AddHeader(pnlWorkspace, "Workspace", "Defina a pasta do projeto, a ISO original e o DAT em que você está trabalhando.");
            txtWorkspacePath = AddPathField(pnlWorkspace, "Pasta do workspace", 92, out btnBrowseWorkspace); btnBrowseWorkspace.Click += btnBrowseWorkspace_Click;
            txtIsoPath = AddPathField(pnlWorkspace, "ISO base", 174, out btnBrowseIso); btnBrowseIso.Click += btnBrowseIso_Click; txtIsoPath.Leave += txtIsoPath_Leave;
            txtDatPath = AddPathField(pnlWorkspace, "DAT ativo", 256, out btnBrowseDat); btnBrowseDat.Click += btnBrowseDat_Click; txtDatPath.Leave += txtDatPath_Leave;
            pnlWorkspace.Controls.Add(new Label { Text = "Estrutura do projeto", Left = 0, Top = 350, Width = 500, Height = 26, Font = new Font("Segoe UI Semibold", 13F) });
            pnlWorkspace.Controls.Add(new Label { Text = "Original / Extracted / Mods / Build / Temp são criadas automaticamente.", Left = 0, Top = 378, Width = 850, Height = 25, ForeColor = Color.FromArgb(145, 151, 163) });
            btnCreateWorkspace = new Button { Left = 0, Top = 420 }; SetupButton(btnCreateWorkspace, "CRIAR WORKSPACE", Color.FromArgb(196, 56, 56), 180); btnCreateWorkspace.Click += btnCreateWorkspace_Click;
            btnOpenWorkspace = new Button { Left = 195, Top = 420 }; SetupButton(btnOpenWorkspace, "ABRIR PASTA", Color.FromArgb(34, 37, 44), 150); btnOpenWorkspace.Click += btnOpenWorkspace_Click;
            lblWorkspaceCurrent = new Label { Text = "Nenhum workspace selecionado", Left = 0, Top = 476, Width = 900, Height = 45, ForeColor = Color.FromArgb(145, 151, 163), AutoEllipsis = true }; pnlWorkspace.Controls.Add(lblWorkspaceCurrent);
        }

        private void BuildToolsDesigner()
        {
            AddHeader(pnlTools, "Ferramentas", "Configure os executáveis usados no seu fluxo atual. O Workspace passa a ser o ponto de entrada.");
            txtIsoAfs = AddToolField(pnlTools, "ISOAFS", 92, out btnBrowseIsoAfs, out btnOpenIsoAfs); btnBrowseIsoAfs.Click += btnBrowseIsoAfs_Click; btnOpenIsoAfs.Click += btnOpenIsoAfs_Click;
            txtDatTool = AddToolField(pnlTools, "DAT Tool", 174, out btnBrowseDatTool, out btnOpenDatTool); btnBrowseDatTool.Click += btnBrowseDatTool_Click; btnOpenDatTool.Click += btnOpenDatTool_Click;
            txtTplManager = AddToolField(pnlTools, "TPL Manager", 256, out btnBrowseTpl, out btnOpenTpl); btnBrowseTpl.Click += btnBrowseTpl_Click; btnOpenTpl.Click += btnOpenTpl_Click;
            txtPcsx2 = AddToolField(pnlTools, "PCSX2", 338, out btnBrowsePcsx2, out btnOpenPcsx2); btnBrowsePcsx2.Click += btnBrowsePcsx2_Click; btnOpenPcsx2.Click += btnOpenPcsx2_Click;
            pnlTools.Controls.Add(new Label { Text = "Integração", Left = 0, Top = 442, Width = 500, Height = 26, Font = new Font("Segoe UI Semibold", 13F) });
            pnlTools.Controls.Add(new Label { Text = "Nesta versão os programas são centralizados e iniciados daqui. A automação virá nas próximas etapas.", Left = 0, Top = 470, Width = 880, Height = 40, ForeColor = Color.FromArgb(145, 151, 163) });
        }

        private void BuildBuildDesigner()
        {
            AddHeader(pnlBuild, "Build & Test", "Finalize o caminho de volta sem perder de vista qual arquivo e projeto estão ativos.");
            pnlBuild.Controls.Add(new Label { Text = "Pipeline", Left = 0, Top = 92, Width = 500, Height = 26, Font = new Font("Segoe UI Semibold", 13F) });
            pnlBuild.Controls.Add(new Label { Text = "REPACK DAT  →  IMPORTAR NA ISO  →  TESTAR", Left = 0, Top = 120, Width = 850, Height = 25, ForeColor = Color.FromArgb(145, 151, 163) });
            btnBuildOpenDat = new Button { Left = 0, Top = 165 }; SetupButton(btnBuildOpenDat, "1  ABRIR DAT TOOL", Color.FromArgb(34, 37, 44), 190); btnBuildOpenDat.Click += btnBuildOpenDat_Click;
            btnBuildOpenIsoAfs = new Button { Left = 205, Top = 165 }; SetupButton(btnBuildOpenIsoAfs, "2  ABRIR ISOAFS", Color.FromArgb(34, 37, 44), 180); btnBuildOpenIsoAfs.Click += btnBuildOpenIsoAfs_Click;
            btnBuildOpenPcsx2 = new Button { Left = 400, Top = 165 }; SetupButton(btnBuildOpenPcsx2, "3  ABRIR PCSX2", Color.FromArgb(196, 56, 56), 180); btnBuildOpenPcsx2.Click += btnBuildOpenPcsx2_Click;
            btnBuildFolder = new Button { Left = 0, Top = 220 }; SetupButton(btnBuildFolder, "ABRIR PASTA BUILD", Color.FromArgb(34, 37, 44), 180); btnBuildFolder.Click += btnBuildFolder_Click;
            rtbBuildLog = new RichTextBox { Left = 0, Top = 280, Width = 902, Height = 220, BackColor = Color.FromArgb(10, 11, 14), ForeColor = Color.FromArgb(183, 190, 200), BorderStyle = BorderStyle.None, ReadOnly = true, Font = new Font("Consolas", 9.5F), Text = "[Workspace] Build assistant pronto.\n" }; pnlBuild.Controls.Add(rtbBuildLog);
            pnlBuild.Controls.Add(btnBuildOpenDat); pnlBuild.Controls.Add(btnBuildOpenIsoAfs); pnlBuild.Controls.Add(btnBuildOpenPcsx2); pnlBuild.Controls.Add(btnBuildFolder);
        }
    }
}
