# RE4 PS2 Mod Workspace v0.1.0

Primeira base do workspace para centralizar o fluxo de modding de Resident Evil 4 (PS2).

## Nesta versão
- Interface WinForms moderna em tema escuro.
- Dashboard do projeto.
- Workspace persistente com pastas `Original`, `Extracted`, `Mods`, `Build` e `Temp`.
- Seleção de ISO base e DAT ativo.
- Configuração e inicialização de ISOAFS, DAT Tool, TPL Manager e PCSX2.
- Assistente visual de Build & Test.
- Configurações persistidas em `%APPDATA%/RE4_PS2_MOD_WORKSPACE`.

> A v0.1.0 centraliza o fluxo existente sem assumir argumentos de linha de comando que ainda não foram mapeados. As próximas integrações podem automatizar extração/repack diretamente.
