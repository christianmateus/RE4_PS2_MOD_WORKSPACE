using System.Diagnostics;
using System.Text.Json;

namespace RE4_PS2_MOD_WORKSPACE;

public partial class Form1 : Form
{
    private readonly string settingsFile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "RE4_PS2_MOD_WORKSPACE", "settings.json");
    private AppSettings settings = new();
    private WorkspaceProject project = new();

    public Form1()
    {
        InitializeComponent();
        LoadSettings();
        ApplyDataToUi();
        ShowPage(pnlDashboard, btnNavDashboard);
    }

    private void ShowPage(Panel page, Button navButton)
    {
        pnlDashboard.Visible = false;
        pnlWorkspace.Visible = false;
        pnlTools.Visible = false;
        pnlBuild.Visible = false;
        page.Visible = true;
        page.BringToFront();

        foreach (var b in new[] { btnNavDashboard, btnNavWorkspace, btnNavTools, btnNavBuild })
        {
            b.BackColor = Color.FromArgb(20, 22, 27);
            b.ForeColor = Color.FromArgb(145, 151, 163);
        }
        navButton.BackColor = Color.FromArgb(34, 37, 44);
        navButton.ForeColor = Color.FromArgb(239, 241, 245);
    }

    private void btnNavDashboard_Click(object? sender, EventArgs e) { RefreshDashboard(); ShowPage(pnlDashboard, btnNavDashboard); }
    private void btnNavWorkspace_Click(object? sender, EventArgs e) { ApplyDataToUi(); ShowPage(pnlWorkspace, btnNavWorkspace); }
    private void btnNavTools_Click(object? sender, EventArgs e) { ApplyDataToUi(); ShowPage(pnlTools, btnNavTools); }
    private void btnNavBuild_Click(object? sender, EventArgs e) { ApplyDataToUi(); ShowPage(pnlBuild, btnNavBuild); }
    private void btnTopBuild_Click(object? sender, EventArgs e) => btnNavBuild_Click(sender, e);
    private void btnDashboardWorkspace_Click(object? sender, EventArgs e) => btnNavWorkspace_Click(sender, e);

    private void btnBrowseWorkspace_Click(object? sender, EventArgs e)
    {
        var selected = BrowseFolder(txtWorkspacePath.Text);
        if (selected == null) return;
        SetWorkspace(selected);
    }

    private void btnCreateWorkspace_Click(object? sender, EventArgs e)
    {
        string? root = string.IsNullOrWhiteSpace(txtWorkspacePath.Text) ? BrowseFolder() : txtWorkspacePath.Text.Trim();
        if (string.IsNullOrWhiteSpace(root)) return;

        try
        {
            SetWorkspace(root);
            MessageBox.Show($"Workspace criado com sucesso.\n\n{root}\n\nPastas criadas: Original, Extracted, Mods, Build e Temp.", "RE4 PS2 Mod Workspace", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show("Não foi possível criar o workspace.\n\n" + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void SetWorkspace(string root)
    {
        root = Path.GetFullPath(root);
        if (!string.Equals(project.RootPath, root, StringComparison.OrdinalIgnoreCase)) LoadProject(root);
        project.RootPath = root;
        EnsureFolders();
        SaveProject();
        txtWorkspacePath.Text = root;
        lblWorkspaceCurrent.Text = root;
        RefreshDashboard();
        WriteLog("Workspace definido: " + root);
    }

    private void btnOpenWorkspace_Click(object? sender, EventArgs e) => OpenFolder(project.RootPath);

    private void btnBrowseIso_Click(object? sender, EventArgs e)
    {
        var path = BrowseFile("ISO do PlayStation 2 (*.iso)|*.iso|Todos os arquivos (*.*)|*.*");
        if (path == null) return;
        project.IsoPath = path; txtIsoPath.Text = path; SaveProject(); RefreshDashboard();
    }

    private void btnBrowseDat_Click(object? sender, EventArgs e)
    {
        var path = BrowseFile("Arquivos DAT (*.dat)|*.dat|Todos os arquivos (*.*)|*.*");
        if (path == null) return;
        project.ActiveDatPath = path; txtDatPath.Text = path; SaveProject(); RefreshDashboard();
    }

    private void txtIsoPath_Leave(object? sender, EventArgs e) { project.IsoPath = Clean(txtIsoPath.Text); SaveProject(); RefreshDashboard(); }
    private void txtDatPath_Leave(object? sender, EventArgs e) { project.ActiveDatPath = Clean(txtDatPath.Text); SaveProject(); RefreshDashboard(); }

    private void btnBrowseIsoAfs_Click(object? sender, EventArgs e) => PickTool(txtIsoAfs, v => settings.IsoAfsPath = v);
    private void btnBrowseDatTool_Click(object? sender, EventArgs e) => PickTool(txtDatTool, v => settings.DatToolPath = v);
    private void btnBrowseTpl_Click(object? sender, EventArgs e) => PickTool(txtTplManager, v => settings.TplManagerPath = v);
    private void btnBrowsePcsx2_Click(object? sender, EventArgs e) => PickTool(txtPcsx2, v => settings.Pcsx2Path = v);
    private void btnOpenIsoAfs_Click(object? sender, EventArgs e) => Launch(settings.IsoAfsPath, "ISOAFS");
    private void btnOpenDatTool_Click(object? sender, EventArgs e) => Launch(settings.DatToolPath, "DAT Tool");
    private void btnOpenTpl_Click(object? sender, EventArgs e) => Launch(settings.TplManagerPath, "TPL Manager");
    private void btnOpenPcsx2_Click(object? sender, EventArgs e) => Launch(settings.Pcsx2Path, "PCSX2");
    private void btnBuildOpenDat_Click(object? sender, EventArgs e) => Launch(settings.DatToolPath, "DAT Tool");
    private void btnBuildOpenIsoAfs_Click(object? sender, EventArgs e) => Launch(settings.IsoAfsPath, "ISOAFS");
    private void btnBuildOpenPcsx2_Click(object? sender, EventArgs e) => Launch(settings.Pcsx2Path, "PCSX2");
    private void btnBuildFolder_Click(object? sender, EventArgs e)
    {
        if (!RequireWorkspace()) return;
        OpenFolder(Path.Combine(project.RootPath!, "Build"));
    }

    private void PickTool(TextBox target, Action<string> setter)
    {
        var path = BrowseFile("Executável (*.exe)|*.exe|Todos os arquivos (*.*)|*.*");
        if (path == null) return;
        target.Text = path; setter(path); SaveSettings();
    }

    private void ApplyDataToUi()
    {
        txtWorkspacePath.Text = project.RootPath ?? "";
        txtIsoPath.Text = project.IsoPath ?? "";
        txtDatPath.Text = project.ActiveDatPath ?? "";
        txtIsoAfs.Text = settings.IsoAfsPath ?? "";
        txtDatTool.Text = settings.DatToolPath ?? "";
        txtTplManager.Text = settings.TplManagerPath ?? "";
        txtPcsx2.Text = settings.Pcsx2Path ?? "";
        lblWorkspaceCurrent.Text = string.IsNullOrWhiteSpace(project.RootPath) ? "Nenhum workspace selecionado" : project.RootPath;
        RefreshDashboard();
    }

    private void RefreshDashboard()
    {
        lblCardWorkspaceValue.Text = ShortPath(project.RootPath, "Nenhum projeto");
        lblCardIsoValue.Text = ShortPath(project.IsoPath, "Não selecionada");
        lblCardDatValue.Text = ShortPath(project.ActiveDatPath, "Nenhum");
        lblCardStatusValue.Text = string.IsNullOrWhiteSpace(project.RootPath) ? "Aguardando projeto" : "Pronto";
    }

    private bool RequireWorkspace()
    {
        if (!string.IsNullOrWhiteSpace(project.RootPath) && Directory.Exists(project.RootPath)) return true;
        MessageBox.Show("Crie ou selecione um workspace primeiro.", "Workspace necessário", MessageBoxButtons.OK, MessageBoxIcon.Information);
        btnNavWorkspace_Click(null, EventArgs.Empty);
        return false;
    }

    private string? BrowseFolder(string? initial = null)
    {
        using var dialog = new FolderBrowserDialog { Description = "Selecione a pasta do RE4 PS2 Mod Workspace", ShowNewFolderButton = true };
        if (!string.IsNullOrWhiteSpace(initial) && Directory.Exists(initial)) dialog.SelectedPath = initial;
        return dialog.ShowDialog(this) == DialogResult.OK ? dialog.SelectedPath : null;
    }

    private string? BrowseFile(string filter)
    {
        using var dialog = new OpenFileDialog { Filter = filter, CheckFileExists = true };
        return dialog.ShowDialog(this) == DialogResult.OK ? dialog.FileName : null;
    }

    private void Launch(string? path, string toolName)
    {
        if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
        {
            MessageBox.Show($"Configure o caminho do {toolName} primeiro.", "Ferramenta não configurada", MessageBoxButtons.OK, MessageBoxIcon.Information);
            btnNavTools_Click(null, EventArgs.Empty); return;
        }
        try
        {
            Process.Start(new ProcessStartInfo(path) { UseShellExecute = true, WorkingDirectory = Path.GetDirectoryName(path)! });
            WriteLog("Aberto: " + toolName);
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Erro ao abrir " + toolName, MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }

    private void OpenFolder(string? path)
    {
        if (string.IsNullOrWhiteSpace(path) || !Directory.Exists(path)) { MessageBox.Show("Pasta não encontrada."); return; }
        Process.Start(new ProcessStartInfo("explorer.exe", $"\"{path}\"") { UseShellExecute = true });
    }

    private void EnsureFolders()
    {
        if (string.IsNullOrWhiteSpace(project.RootPath)) throw new InvalidOperationException("Nenhuma pasta de workspace foi selecionada.");
        Directory.CreateDirectory(project.RootPath);
        foreach (var name in new[] { "Original", "Extracted", "Mods", "Build", "Temp" }) Directory.CreateDirectory(Path.Combine(project.RootPath, name));
    }

    private void WriteLog(string text)
    {
        if (rtbBuildLog == null || rtbBuildLog.IsDisposed) return;
        rtbBuildLog.AppendText($"[{DateTime.Now:HH:mm:ss}] {text}{Environment.NewLine}");
    }

    private void LoadSettings()
    {
        try
        {
            if (File.Exists(settingsFile)) settings = JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(settingsFile)) ?? new();
            if (!string.IsNullOrWhiteSpace(settings.LastWorkspace)) LoadProject(settings.LastWorkspace);
        }
        catch { settings = new(); project = new(); }
    }

    private void SaveSettings()
    {
        Directory.CreateDirectory(Path.GetDirectoryName(settingsFile)!);
        File.WriteAllText(settingsFile, JsonSerializer.Serialize(settings, JsonOptions()));
    }

    private void LoadProject(string root)
    {
        try
        {
            var file = Path.Combine(root, ".re4workspace.json");
            project = File.Exists(file) ? JsonSerializer.Deserialize<WorkspaceProject>(File.ReadAllText(file)) ?? new() : new WorkspaceProject();
            project.RootPath = root;
        }
        catch { project = new WorkspaceProject { RootPath = root }; }
    }

    private void SaveProject()
    {
        if (string.IsNullOrWhiteSpace(project.RootPath)) return;
        EnsureFolders();
        File.WriteAllText(Path.Combine(project.RootPath, ".re4workspace.json"), JsonSerializer.Serialize(project, JsonOptions()));
        settings.LastWorkspace = project.RootPath;
        SaveSettings();
    }

    private static JsonSerializerOptions JsonOptions() => new() { WriteIndented = true };
    private static string? Clean(string value) => string.IsNullOrWhiteSpace(value) ? null : value.Trim();
    private static string ShortPath(string? path, string fallback) => string.IsNullOrWhiteSpace(path) ? fallback : Path.GetFileName(path.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar));
}

public sealed class AppSettings
{
    public string? IsoAfsPath { get; set; }
    public string? DatToolPath { get; set; }
    public string? TplManagerPath { get; set; }
    public string? Pcsx2Path { get; set; }
    public string? LastWorkspace { get; set; }
}

public sealed class WorkspaceProject
{
    public string? RootPath { get; set; }
    public string? IsoPath { get; set; }
    public string? ActiveDatPath { get; set; }
}
